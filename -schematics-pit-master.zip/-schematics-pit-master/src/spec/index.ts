import { strings } from '@angular-devkit/core';
import { apply, filter, mergeWith, move, noop, Rule, SchematicContext, SchematicsException, template, Tree, url } from '@angular-devkit/schematics';
import { parseName } from '@schematics/angular/utility/parse-name';
import { buildDefaultPath } from '@schematics/angular/utility/project';
import { Schema, TestType } from './schema';

function getPrefix(workspaceConfig: any, type: TestType) {
  return workspaceConfig &&
         workspaceConfig.schematics &&
         workspaceConfig.schematics[`@schematics/angular:${type}`] &&
         workspaceConfig.schematics[`@schematics/angular:${type}`].prefix ||
         '';
}

// You don't have to export the function as default. You can also have more than one rule factory
// per file.
export default function(_options: Schema): Rule {
  return (tree: Tree, _context: SchematicContext) => {
    const workspaceConfigBuffer = tree.read('angular.json');
    if(!workspaceConfigBuffer) {
      throw new SchematicsException('Not an Angular CLI workspace');
    }

    const workspaceConfig = JSON.parse(workspaceConfigBuffer.toString());
    const projectName = _options.project || workspaceConfig.defaultProject;
    const project = workspaceConfig.projects[projectName];
    const prefix = getPrefix(workspaceConfig, _options.type);

    const defaultProjectPath = buildDefaultPath(project);

    const parsedPath = parseName(defaultProjectPath, _options.name);

    const { name, path } = parsedPath;

    const sourceTemplate = url('./files');

    const sourceParametrizedTemplate = apply(sourceTemplate, [
      _options.type === TestType.component ? filter( path => path.endsWith('.component.spec.ts') ) : noop(),
      _options.type === TestType.service   ? filter( path => path.endsWith('.service.spec.ts') )   : noop(),
      _options.type === TestType.directive ? filter( path => path.endsWith('.directive.spec.ts') ) : noop(),
      _options.type === TestType.store     ? filter( path => path.includes('/spec/') ) : noop(),
      template({
        ..._options,
        ...strings,
        'if-flat': (s: string) => _options.flat ? '' : s,
        prefix,
        name,
        upperize,
      }),
      move(path)
    ]);

    function upperize( s: string ) {
      return strings.underscore(s).toUpperCase();
    }

    return mergeWith(sourceParametrizedTemplate)(tree, _context);
  };
}
