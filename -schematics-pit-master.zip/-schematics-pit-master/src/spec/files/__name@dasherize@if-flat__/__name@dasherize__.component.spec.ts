import { async, TestBed } from '@angular/core/testing';
import { configureTestSuite, createStableTestContext, TestCtx } from 'ng-bullet';
import { <%= classify(name) %>Component } from './<%= dasherize(name) %>.component';

describe('<%= classify(name) %>Component', () => {
  let context: TestCtx<<%= classify(name) %>Component>;

  configureTestSuite(() => {
    TestBed.configureTestingModule({
      declarations: [ <%= classify(name) %>Component ],
    })
  });

  beforeEach(async( async () => {
    context = await createStableTestContext(<%= classify(name) %>Component);
  } ));

  it('should create', () => {
    expect(context.component).toBeTruthy();
  });


  /** prevent memory leaks by removing leftover styles in <head> */
  function cleanStylesFromDom(): void {
    const head = document.head;
    const styles = Array.from(head.querySelectorAll('style'));
    for( const style of styles ) head.removeChild( style );
  }
  afterAll(cleanStylesFromDom);
});
