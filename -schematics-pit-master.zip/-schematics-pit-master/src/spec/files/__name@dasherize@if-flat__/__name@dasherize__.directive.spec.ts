import { async, TestBed } from '@angular/core/testing';
import { configureTestSuite, createStableTestContext, TestCtx } from 'ng-bullet';
import { <%= classify(name) %>Directive } from './<%= dasherize(name) %>.directive';
import { Component, ViewChild } from '@angular/core';

@Component({
  template: `<div [<%= prefix %><%= classify(name) %>]></div>`
})
class TestComponent {

  @ViewChild(<%= classify(name) %>Directive)
  directive: <%= classify(name) %>Directive;

}

describe('<%= classify(name) %>Directive', () => {
  let context: TestCtx<TestComponent>;
  let directive: <%= classify(name) %>Directive;

  configureTestSuite(() => {
    TestBed.configureTestingModule({
      declarations: [
        TestComponent,
        <%= classify(name) %>Directive,
      ],
    })
  });

  beforeEach(async( async () => {
    context = await createStableTestContext(TestComponent);
    directive = context.component.directive;
  } ));

  it('should create', () => {
    expect(context.component).toBeTruthy();
    expect(directive).toBeTruthy();
  });


  /** prevent memory leaks by removing leftover styles in <head> */
  function cleanStylesFromDom(): void {
    const head = document.head;
    const styles = Array.from(head.querySelectorAll('style'));
    for( const style of styles ) head.removeChild( style );
  }
  afterAll(cleanStylesFromDom);
});
