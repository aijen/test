import { AppState } from 'shared/models/state.model';
import { <%= dasherize(name) %>Reducer, initialState } from '../<%= dasherize(name) %>.reducer';

// necessary to avoid the error :
// Invalid module name in augmentation, module 'shared/models/state.model' cannot be found.
let happy_compiler: AppState; // tslint:disable-line

describe('<%= classify(name) %> Reducer', () => {

  describe('undefined action', () => {

    it('should return the default state', () => {
      const action = { type: null, payload: null };
      const state = <%= dasherize(name) %>Reducer( undefined, action );

      expect(state).toBe(initialState);
    })

  });

} );
