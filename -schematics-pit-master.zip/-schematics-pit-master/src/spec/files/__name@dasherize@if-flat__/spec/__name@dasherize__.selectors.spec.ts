
describe('<%= classify(name) %> Selectors', () => {

} );
