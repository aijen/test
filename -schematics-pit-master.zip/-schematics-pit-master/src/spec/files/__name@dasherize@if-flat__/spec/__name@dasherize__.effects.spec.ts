import { HttpClientTestingModule, HttpTestingController } from '@angular/common/http/testing';
import { TestBed } from '@angular/core/testing';
import { provideMockActions } from '@ngrx/effects/testing';
import { provideMockStore } from '@ngrx/store/testing';
import { configureTestSuite } from 'ng-bullet';
import { Observable } from 'rxjs';
import { marbles } from 'rxjs-marbles/jasmine';
import { AppState } from 'shared/models/state.model';
import { <%= classify(name) %>Effects } from '../<%= dasherize(name) %>.effects';
import { initialState as initial<%= classify(name) %>State } from '../<%= dasherize(name) %>.reducer';

describe('<%= classify(name) %> Effects', () => {
  let effects: <%= classify(name) %>Effects;
  let actions: Observable<any>;
  let httpTestingController: HttpTestingController;
  const initialState: Partial<AppState> = { <%= dasherize(name) %>: initial<%= classify(name) %>State };

  configureTestSuite(() => {
    TestBed.configureTestingModule({
      imports: [ HttpClientTestingModule ],
      providers: [
        <%= classify(name) %>Effects,
        provideMockActions(() => actions),
        provideMockStore<Partial<AppState>>({ initialState }),
      ]
    });
  } );

  beforeEach(() => {
    httpTestingController = TestBed.get(HttpTestingController);
    effects = TestBed.get(<%= classify(name) %>Effects);
  });

  afterEach(() => {
    httpTestingController.verify();
  });

  it('should work', () => {
    expect(effects).toBeTruthy();
  });

} );
