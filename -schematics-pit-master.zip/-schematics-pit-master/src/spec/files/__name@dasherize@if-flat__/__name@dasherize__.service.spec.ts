import { inject, TestBed } from '@angular/core/testing';
import { configureTestSuite } from 'ng-bullet';
import { <%= classify(name) %>Service } from './<%= dasherize(name) %>.service';

describe('<%= classify(name) %>Service', () => {

  configureTestSuite(() => {
    TestBed.configureTestingModule({
      providers: [ <%= classify(name) %>Service ],
    })
  });

  it('should be created', inject(
    [<%= classify(name) %>Service],
    (service: <%= classify(name) %>Service) => {
      expect(service).toBeTruthy();
    }
  ));


  /** prevent memory leaks by removing leftover styles in <head> */
  function cleanStylesFromDom(): void {
    const head = document.head;
    const styles = Array.from(head.querySelectorAll('style'));
    for( const style of styles ) head.removeChild( style );
  }
  afterAll(cleanStylesFromDom);
});
