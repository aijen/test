/**
 * Pit Options Schema
 * Pit Schematics
 */
export interface Schema {
    /**
     * test name
     */
    name: string;
    /**
     * test type
     */
    type: TestType;
    /**
     * Angular CLI workspace project
     */
    project?: string;
    /**
     * When true, creates the new files at the top level of the current project.
     */
    flat?: boolean;
}

export const enum TestType {
    component = 'component',
    service = 'service',
    directive = 'directive',
    store = 'store',
}
