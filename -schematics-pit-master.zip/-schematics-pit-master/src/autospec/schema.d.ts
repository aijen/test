/**
 * Pit Options Schema
 * Pit Schematics
 */
export interface Schema {
    /**
     * test file
     */
    file: string;
    /**
     * Angular CLI workspace project
     */
    project?: string;
    classname?: string;
    subdir?: string;
}
