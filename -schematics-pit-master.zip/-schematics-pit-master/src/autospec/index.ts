import { strings, join, normalize, Path, dirname, relative, basename } from '@angular-devkit/core';
import { apply, mergeWith, move, Rule, SchematicContext, SchematicsException, template, Tree, url } from '@angular-devkit/schematics';
import { buildDefaultPath } from '@schematics/angular/utility/project';
import { Schema } from './schema';
import { createSourceFile, ScriptTarget, SyntaxKind, Node, ClassDeclaration, ConstructorDeclaration, TypeNode, TypeReferenceNode, ImportDeclaration, SourceFile, NamedImports, StringLiteral, CallExpression, MethodDeclaration, PropertyAssignment } from 'typescript';
import { parseFragment, DefaultTreeDocumentFragment, DefaultTreeElement, DefaultTreeParentNode, Attribute, Location } from 'parse5';

type ControllerType = 'Component' | 'Directive' | 'Injectable';
type selectorPrefix = {directivePrefix: string, componentPrefix: string};
interface Provider {
  provide: string,
  provider: string,
  optional?: boolean,
  typeParameters?: string,
}

function getPrefix(workspaceConfig: any): selectorPrefix {
  return {
    directivePrefix:  workspaceConfig &&
                      workspaceConfig.schematics &&
                      workspaceConfig.schematics[`@schematics/angular:directive`] &&
                      workspaceConfig.schematics[`@schematics/angular:directive`].prefix ||
                      '',
    componentPrefix:  workspaceConfig &&
                      workspaceConfig.schematics &&
                      workspaceConfig.schematics[`@schematics/angular:component`] &&
                      workspaceConfig.schematics[`@schematics/angular:component`].prefix ||
                      ''
  };
}

function getPathReplacements( tsConfig: any ) {
  if( !(tsConfig && tsConfig.compilerOptions) ) return [];
  const baseUrl = tsConfig.compilerOptions.baseUrl || '';
  const defaultPath: [RegExp, string][] = [[ /^([^.].+?)$/, join(normalize('/'), baseUrl, '$1') ]];
  if( !(tsConfig && tsConfig.compilerOptions && tsConfig.compilerOptions.paths) ) return defaultPath;
  const paths: { [key: string]: string[] } = tsConfig.compilerOptions.paths;
  return Object.entries(paths).map( ([key, [value]]) => [ new RegExp(`^${key.replace('*', '(.+?)')}$`), join(normalize('/'), baseUrl, value.replace('*', '$1')) ] as [RegExp, string]).concat(defaultPath);
}

function readSourceFile(host: Tree, filepath: string) {
  const source = host.read(filepath);
  if(!source) throw new Error(`File ${filepath} does not exist.`);
  return createSourceFile(filepath, source.toString('utf-8'), ScriptTarget.Latest, true);
}

function isTypeReference(node: TypeNode): node is TypeReferenceNode {
  return node && node.kind === SyntaxKind.TypeReference;
}
function isNamedImports(node: any): node is NamedImports {
  return node && node.kind === SyntaxKind.NamedImports;
}
function isStringLiteral(node: any): node is StringLiteral {
  return node && node.kind === SyntaxKind.StringLiteral;
}

function getConstructorTypeReferences( classDeclaration: ClassDeclaration ) {
  const classConstructor = findNodes<ConstructorDeclaration>(classDeclaration, SyntaxKind.Constructor, 1)[0];
  if(!classConstructor) return [];
  const types = classConstructor.parameters.map( p => p.type );
  const typeReferences = types.filter(isTypeReference);
  return typeReferences;
}

function getPublicMethods( classDeclaration: ClassDeclaration ) {
  return findNodes<MethodDeclaration>(classDeclaration, SyntaxKind.MethodDeclaration).filter(
    method => !method.modifiers || method.modifiers.some( modifier => modifier.kind === SyntaxKind.PublicKeyword )
      || method.modifiers.every( modifier => modifier.kind !== SyntaxKind.PrivateKeyword && modifier.kind !== SyntaxKind.ProtectedKeyword )
  );
}

function getImports( file: SourceFile ): { [key: string]: string; } {
  const imports = findNodes<ImportDeclaration>( file, SyntaxKind.ImportDeclaration);
  return imports.map(
    ({ moduleSpecifier, importClause }: ImportDeclaration) =>
      isStringLiteral(moduleSpecifier) &&
      importClause &&
      isNamedImports(importClause.namedBindings) &&
      importClause.namedBindings.elements.map( elem => ({ [elem.name.getText()]: moduleSpecifier.text }) ).reduce( (acc, curr) => ({...acc, ...curr}), {} )
    )
    .filter<{ [key: string]: string; }>( (v): v is { [key: string]: string; } => Boolean(v) )
    .reduce( (acc: { [key: string]: string; }, curr) =>  ({...acc, ...curr}), {} );
}

function getDependencyFile( dependencies: string, imports: { [key: string]: string; }, pathReplacements: [RegExp, string][], sourcePath: Path ) {
    const importPath = imports[dependencies];
    const replacement = pathReplacements.find( ([reg]) => new RegExp(reg).test( importPath ) );
    if(!replacement) return normalize(join(sourcePath, importPath));
    return importPath.replace(replacement[0], replacement[1]);
}

function getFilePublicMethods( classDeclaration: ClassDeclaration ) {
  const methods = getPublicMethods( classDeclaration );
  return methods.map( m => `'${m.name.getText()}'` );
}

function getClassDeclaration( host: Tree, filePath: string, classname?: string ): ClassDeclaration {
  const source = readSourceFile( host, filePath );
  const classDeclarations = findNodes<ClassDeclaration>( source, SyntaxKind.ClassDeclaration );

  if( !classDeclarations.length ) {
    throw new Error(`Could not find any class declaration in file '${filePath}'`);
  }
  if( classDeclarations.length === 1 && !classname ) {
    return classDeclarations[0];
  }
  if( !classname ) {
    throw new Error(`Multiple class declaration found. Please provide a classname for '${filePath}'`);
  }
  let classDeclaration = classDeclarations.find( cd => cd.name && cd.name.getText() === classname );
  if(!classDeclaration) throw new Error(`Could not find class declaration : ${classname} in '${filePath}'`);
  return classDeclaration;
}

function getTemplateComponentAndDirective(type: ControllerType, typeDecorator: CallExpression, host: Tree, dirname: Path, prefix: selectorPrefix, TestImportsDeclarations: string[], TestImports: string[], has: { [k: string]: boolean }) {
  const componentsControllers = new Map<string, { inputs: Set<string> }>();
  const directivesControllers = new Map<string, { type: 'Input' | 'Output' | undefined }>();
  const res = { componentsControllers, directivesControllers };

  if(type !== 'Component') return res;

  const config = findNodes<PropertyAssignment>(typeDecorator, SyntaxKind.PropertyAssignment);
  if(!config) return res;

  const property = config.find( c => (c.name.getText() === 'template') || (c.name.getText() === 'templateUrl') );
  if(!property) return res;

  let initializer: StringLiteral;
  if(property.initializer.kind !== SyntaxKind.StringLiteral) return res;
  initializer = property.initializer as StringLiteral;

  let template: string;
  if(property.name.getText() === 'template') template = initializer.text;
  else {
    const filepath = join(dirname, initializer.text);
    const source = host.read(filepath);
    if(!source) throw new Error(`File ${dirname} does not exist.`);
    template = source.toString('utf-8');
  }

  const { componentPrefix, directivePrefix } = prefix;
  const possiblePrefix = [ 'cockpit', componentPrefix, directivePrefix ];
  const prefixRegexp = new RegExp( `^(?:\\(|\\[)?(?:${possiblePrefix.join('|')}).`, 'g' );
  const bindingRegexp = new RegExp( `^(?:\\(|\\[)|(?:\\)|\\])$`, 'g' );

  const isElement = ( node: any ): node is DefaultTreeElement => Array.isArray(node.attrs) && Array.isArray(node.childNodes);
  const getChildElements = ( node: DefaultTreeParentNode ) => node.childNodes.filter(isElement);
  const findElements = ( acc: DefaultTreeElement[], node: DefaultTreeElement ): DefaultTreeElement[] => [ ...acc, node, ...getChildElements(node).reduce( findElements, [] ) ];
  const hasProjectPrefix = ( v: string ) => new RegExp(prefixRegexp).test( v );
  const getSource = ( location: Location ) => template.slice( location.startOffset, location.endOffset );
  const getSourceAttributeName = ( location: Location ) => getSource(location).split('=')[0];
  const getSourceAttributeNameFromElement = ( element: DefaultTreeElement, attr: string ) => getSourceAttributeName(element.sourceCodeLocation!.attrs[attr]);

  const html = parseFragment(template, { sourceCodeLocationInfo: true }) as DefaultTreeDocumentFragment;
  const elements = getChildElements(html).reduce( findElements, [] );
  const attributes = elements.reduce( (acc, element) => new Set([...acc, ...element.attrs.map( attr => attr.name.replace( bindingRegexp, '' ) )]), new Set<string>() );
  const projectElements = elements.filter( element => hasProjectPrefix(element.nodeName) );
  const projectDirectives = elements.reduce( (acc, node) => [...acc, ...node.attrs.filter( attr => hasProjectPrefix(attr.name) ).map( attr => [attr, node.sourceCodeLocation!.attrs[attr.name]] as [Attribute, Location] ) ], [] );

  for(let element of projectElements) {
    const name = getSource(element.sourceCodeLocation!).match( new RegExp( `(${element.nodeName})`, 'i' ) )![0];
    if( !componentsControllers.has(name) ) componentsControllers.set(name, { inputs: new Set() });
    const controller = componentsControllers.get(name)!;
    const attrs = element.attrs.filter(attr => !attr.name.startsWith('(') && !attr.name.startsWith('*') && !attr.name.startsWith('[@') && !projectDirectives.find( ([directive]) => directive.name === attr.name ) )
      .map( attr => getSourceAttributeNameFromElement(element, attr.name).replace( bindingRegexp, '' ) )
    controller.inputs = new Set([...controller.inputs, ...attrs]);
  }

  for(let [directive, location] of projectDirectives) {
    const name = getSourceAttributeName(location).replace( bindingRegexp, '' );
    if( !directivesControllers.has(name) ) directivesControllers.set(name, { type: undefined });
    const controller = directivesControllers.get(name)!;
    const [binding] = directive.name;
    controller.type = controller.type || (binding === '[' ? 'Input' : binding === '(' ? 'Output' : undefined);
  }

  for(const element of elements.reduce( (acc, element) => new Set([...acc, element.nodeName]), new Set<string>() )) {
    switch( element ) {
      case 'mat-select':
        TestImportsDeclarations.push(`import { MatSelectModule } from '@angular/material/select';`);
        TestImports.push(`MatSelectModule,`);
        break;
      case 'mat-spinner':
        TestImportsDeclarations.push(`import { MatProgressSpinnerModule } from '@angular/material/progress-spinner';`);
        TestImports.push(`MatProgressSpinnerModule,`);
        break;
      case 'mat-radio-button':
        TestImportsDeclarations.push(`import { MatRadioModule } from '@angular/material/radio';`);
        TestImports.push(`MatRadioModule,`);
        break;
      case 'mat-checkbox':
        TestImportsDeclarations.push(`import { MatCheckboxModule } from '@angular/material/checkbox';`);
        TestImports.push(`MatCheckboxModule,`);
        break;
      case 'router-outlet':
        if(has.router) continue;
        has.router = true;
        TestImportsDeclarations.push(`import { RouterTestingModule } from '@angular/router/testing';`);
        TestImports.push(`RouterTestingModule,`);
        break;
    }
  }

  let hasAnimations = false;
  for(const attribute of attributes) {
    if( attribute.startsWith('@') ) {
      hasAnimations = true;
      continue;
    }
    switch( attribute ) {
      case 'mattooltip':
        TestImportsDeclarations.push(`import { MatTooltipModule } from '@angular/material/tooltip';`);
        TestImports.push('MatTooltipModule,');
        break;
      case 'ngbtooltip':
        TestImportsDeclarations.push(`import { NgbTooltipModule } from '@ng-bootstrap/ng-bootstrap';`);
        TestImports.push('NgbTooltipModule,');
        break;
      case 'ngrxformcontrolstate':
        TestImportsDeclarations.push(`import { NgrxFormsModule } from 'ngrx-forms';`);
        TestImports.push('NgrxFormsModule,');
        break;
      case 'cdktextareaautosize':
        TestImportsDeclarations.push(`import { TextFieldModule } from '@angular/cdk/text-field';`);
        TestImports.push('TextFieldModule,');
        break;
    }
  }

  if(hasAnimations) {
    TestImportsDeclarations.push(`import { NoopAnimationsModule } from '@angular/platform-browser/animations';`);
    TestImports.push(`NoopAnimationsModule,`);
  }

  return res;
}

function findNodes<T = Node>(node: Node, kind: SyntaxKind, max = Infinity): T[] {
  if (!node || max == 0) return [];
  const arr: T[] = [];
  if (node.kind === kind) {
    arr.push(node as unknown as T);
    max--;
  }
  if (max > 0) {
    for (const child of node.getChildren()) {
      findNodes<T>(child, kind, max).forEach(node => {
        if (max > 0) {
          arr.push(node);
        }
        max--;
      });
      if (max <= 0) {
        break;
      }
    }
  }
  return arr;
}

function toRelative( path: string ) {
  return path.startsWith('./') || path.startsWith('../') ? path : `./${path}`;
}

// You don't have to export the function as default. You can also have more than one rule factory
// per file.
export default function(_options: Schema): Rule {
  return (tree: Tree, _context: SchematicContext) => {
    const workspaceConfigBuffer = tree.read('angular.json');
    const tsConfigBuffer = tree.read('tsconfig.json');
    if(!workspaceConfigBuffer || !tsConfigBuffer) {
      throw new SchematicsException('Not an Angular CLI workspace');
    }

    const workspaceConfig = JSON.parse(workspaceConfigBuffer.toString());
    const tsConfig = JSON.parse(tsConfigBuffer.toString());
    const projectName = _options.project || workspaceConfig.defaultProject;
    const project = workspaceConfig.projects[projectName];
    const prefix = getPrefix(workspaceConfig);
    const pathReplacements = getPathReplacements(tsConfig);

    const defaultProjectPath = buildDefaultPath(project);

    let filepath = join(normalize('/'), _options.file);
    if( !tree.exists( filepath ) ) {
      filepath = join(normalize(defaultProjectPath), _options.file);
    }
    if( !tree.exists( filepath ) ) {
      throw new Error(`Could not find ${_options.file}`);
    }
    const filename = basename( filepath ).replace(/\.ts$/, '');
    const path = dirname( filepath );

    const subdir = join(path, _options.subdir || '');
/*  */
    const file = readSourceFile(tree, filepath);
    let classDeclaration = getClassDeclaration( tree, filepath, _options.classname );

    let type: ControllerType | undefined;
    if(!classDeclaration.decorators || !classDeclaration.decorators.length) throw new Error('class neither a component, directive or service');
    const decorators = classDeclaration.decorators.map(({expression}) => (expression)).filter( (expression): expression is CallExpression => expression.kind === SyntaxKind.CallExpression );
    const typeDecorator = decorators.find( (call) => ['Component', 'Directive', 'Injectable'].includes(call.expression.getText()) );
    if(!typeDecorator) throw new Error('class neither a component, directive or service');
    type = typeDecorator.expression.getText() as ControllerType;

    const className = classDeclaration.name && classDeclaration.name.text;
    if(!className) throw new Error('class is not named');

    const dependencyTypes = getConstructorTypeReferences(classDeclaration).map(t => t.typeName.getText());
    const imports = getImports( file );

    const TestImportsDeclarations: string[] = [];
    const TestImports: string[] = [];
    const TestProviders: string[] = [];
    const TestDeclarations: string[] = [];
    const TestProvidersStub: Provider[] = [];
    const has = {
      router: false,
      http: false,
      store: false,
    }

    TestImportsDeclarations.push(`import { ${className} } from '${toRelative(relative(subdir, join(path, filename)))}';`);

    const { componentsControllers, directivesControllers } = getTemplateComponentAndDirective(type, typeDecorator, tree, path, prefix, TestImportsDeclarations, TestImports, has);

    if(TestImports.includes('MatSelectModule,') && TestImports.includes('NgrxFormsModule,')) {
      TestImportsDeclarations.push(`import { NgrxMatSelectViewAdapter } from 'shared/directives/mat-select-view-adapter/mat-select-view-adapter';`);
      TestDeclarations.push(`NgrxMatSelectViewAdapter,`);
    }

    for( const dep of dependencyTypes ) {
      if(imports[dep] === '@angular/core' && dep === 'ElementRef') {
        continue;
      }
      if(imports[dep] === '@angular/router') {
        if(has.router) continue;
        has.router = true;
        TestImportsDeclarations.push(`import { RouterTestingModule } from '@angular/router/testing';`);
        TestImports.push(`RouterTestingModule,`);
        continue;
      }
      if(imports[dep] === '@angular/common/http' && dep === 'HttpClient') {
        if(has.http) continue;
        has.http = true;
        TestImportsDeclarations.push(`import { HttpClientTestingModule, HttpTestingController } from '@angular/common/http/testing';`);
        TestImports.push(`HttpClientTestingModule,`);
        continue;
      }
      if(imports[dep] === '@ngrx/store' && dep === 'Store' || imports[dep] === '@ngrx/effects' && dep === 'Actions') {
        if(has.store) continue;
        has.store = true;
        TestImportsDeclarations.push(`import { provideMockStore } from '@ngrx/store/testing';`);
        TestImportsDeclarations.push(`import { provideMockActions } from '@ngrx/effects/testing';`);
        TestImportsDeclarations.push(`import { AppState } from 'shared/models/state.model';`);
        TestImportsDeclarations.push(`import { Observable } from 'rxjs';`);
        TestProviders.push(`provideMockStore<Partial<AppState>>({ initialState: {} }),`);
        TestProviders.push(`provideMockActions(() => actions),`);
        continue;
      }

      const file = `${getDependencyFile(dep, imports, pathReplacements, path)}.ts`;
      try {
        const fileClassDeclaration = getClassDeclaration(tree, file, dep);
        const methods = getFilePublicMethods(fileClassDeclaration);
        const typeParameters = fileClassDeclaration.typeParameters ? `<${fileClassDeclaration.typeParameters.map(() => 'any').join(', ')}>` : '';
        const importPath = imports[dep].startsWith('./') || imports[dep].startsWith('../') ? toRelative(relative(subdir, join(path, imports[dep]))) : imports[dep];
        TestImportsDeclarations.push(`import { ${dep} } from '${importPath}';`);
        if(methods.length) {
          TestProvidersStub.push({provide: dep, typeParameters, provider: `{ provide: ${dep}, useFactory: () => jasmine.createSpyObj('${dep}', [${methods.join(`, `)}] as Array<keyof ${dep}${typeParameters}>) },`});
        } else {
          TestProvidersStub.push({provide: dep, typeParameters, provider: `{ provide: ${dep}, useFactory: () => ({}) },`});
        }
      } catch(e) {
        TestImportsDeclarations.push(`/* import { ${dep} } from '${imports[dep]}'; */`);
        TestProvidersStub.push({provide: dep, optional: true, provider: `/* { provide: ${dep}, useFactory: () => jasmine.createSpyObj('${dep}', [] as Array<keyof ${dep}>) }, */`});
      }
    }



/*  */
    const sourceTemplate = url('./files');

    const sourceParametrizedTemplate = apply(sourceTemplate, [
      template({
        ..._options,
        ...strings,
        ...prefix,
        name: filename,
        className,
        upperize,
        TestImportsDeclarations,
        TestImports,
        TestProviders,
        TestDeclarations,
        TestProvidersStub,
        hasRouter: has.router,
        hasHttp: has.http,
        hasStore: has.store,
        isComponent: type === 'Component',
        isDirective: type === 'Directive',
        isInjectable: type === 'Injectable',
        componentsControllers,
        directivesControllers,
      }),
      move(subdir)
    ]);

    function upperize( s: string ) {
      return strings.underscore(s).toUpperCase();
    }

    return mergeWith(sourceParametrizedTemplate)(tree, _context);
  };
}
