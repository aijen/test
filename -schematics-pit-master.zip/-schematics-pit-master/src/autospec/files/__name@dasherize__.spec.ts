<%
if( componentsControllers.size || directivesControllers.size ) {
%>import { Component, Directive, Input, Output, EventEmitter } from '@angular/core';
<%
}
%>import { async, TestBed } from '@angular/core/testing';
import { configureTestSuite<% if(isComponent || isDirective) { %>, createStableTestContext, TestCtx<% } %> } from 'ng-bullet';<%
for( let importDeclaration of TestImportsDeclarations) {
%>
<%= importDeclaration %><%
}
%><%
if(isDirective) { %>
import { Component, ViewChild } from '@angular/core';

@Component({
  template: `<div <%= directivePrefix %><%= className.replace(/Directive$/, '') %>></div>`
})
class TestComponent {

  @ViewChild(<%= className %>)
  directive: <%= className %>;

}<%
} %><%
for( let [name, {inputs}] of componentsControllers.entries() ) { %>

@Component({
  selector: '<%= name %>',
  template: '',
})
class <%= classify(name) %>StubComponent {<%
if( inputs.size ) {
%><%
for( let input of inputs ) { %>
  // @Input() <%= input %>: any;<%
} %>
<%
} %>}<%
} %><%
for( let [name, {type}] of directivesControllers.entries() ) { %>

@Directive({
  selector: '[<%= name %>]',
})
class <%= classify(name) %>StubDirective {<%
if(type) { %>
  @<%= type %>() <%= name %><% if(type === 'Output') { %> = new EventEmitter<any>();<% } else { %>: any;<% } %>
<%
}
%>}<%
} %>

describe('<%= className %>', () => {<%
if(isComponent) { %>
  let context: TestCtx<<%= className %>>;<%
} %><%
if(isDirective) { %>
  let context: TestCtx<TestComponent>;
  let directive: <%= className %>;<%
} %><%
if(isInjectable) { %>
  let service: <%= className %>;<%
} %><%
if(hasHttp) { %>
  let httpTestingController: HttpTestingController;<%
} %><%
if(hasStore) { %>
  let actions: Observable<any>;<%
} %><%
for( let providerStub of TestProvidersStub) { %>
  <% if(providerStub.optional) { %>/* <% } %>let <%= camelize(providerStub.provide) %>Stub: jasmine.SpyObj<<%= providerStub.provide %><% if(providerStub.typeParameters) { %><%= providerStub.typeParameters %><% } %>>;<% if(providerStub.optional) { %> */<% } %><%
} %>

  configureTestSuite(() => {
    TestBed.configureTestingModule({
      imports: [<%
      for( let importDeclaration of TestImports) { %>
        <%= importDeclaration %><%
      } %>
      ],<%
    if(isComponent || isDirective) { %>
      declarations: [
        <%= className %>,<%
      if(isDirective) { %>
        TestComponent,<%
      } %><%
      for(let declaration of TestDeclarations) { %>
        <%= declaration %><%
      } %><%
      for( let name of componentsControllers.keys() ) { %>
        <%= classify(name) %>StubComponent,<%
      } %><%
      for( let name of directivesControllers.keys() ) { %>
        <%= classify(name) %>StubDirective,<%
      } %>
      ],<%
    } %><%
    if(TestProviders.length || isInjectable || TestProvidersStub.length) { %>
      providers: [<%
      if(isInjectable) { %>
        <%= className %>,<%
      } %><%
      for( let providerDeclaration of TestProviders) { %>
        <%= providerDeclaration %><%
      } %><%
      for( let providerStub of TestProvidersStub) { %>
        <%= providerStub.provider %><%
      } %>
      ],<%
    } %>
    })
  });

  beforeEach(<% if(isComponent || isDirective) { %>async( async<% } %> () => {<%
  if(hasStore) { %>
    actions = null;<%
  } %><%
  for( let providerStub of TestProvidersStub) { %>
    <% if(providerStub.optional) { %>/* <% } %><%= camelize(providerStub.provide) %>Stub = TestBed.get(<%= providerStub.provide %>);<% if(providerStub.optional) { %> */<% } %><%
  } %><%
  if(isComponent) { %>
    context = await createStableTestContext(<%= className %>);<%
  } %><%
  if(isDirective) { %>
    context = await createStableTestContext(TestComponent);
    directive = context.component.directive;<%
  } %><%
  if(isInjectable) { %>
    service = TestBed.get(<%= className %>);<%
  } %><%
  if(hasHttp) { %>
    httpTestingController = TestBed.get(HttpTestingController);<% }
  %>
  } <% if(isComponent || isDirective) { %>)<% } %>);<%
if(hasHttp) { %>

  afterEach(() => {
    httpTestingController.verify();
  });<%
} %>

  it('should create', () => {<%
  if(isComponent || isDirective) { %>
    expect(context.component).toBeTruthy();<%
  } %><%
  if(isDirective) { %>
    expect(directive).toBeTruthy();<%
  } %><%
  if(isInjectable) { %>
    expect(service).toBeTruthy();<%
  } %>
  });


  /** prevent memory leaks by removing leftover styles in <head> */
  function cleanStylesFromDom(): void {
    const head = document.head;
    const styles = Array.from(head.querySelectorAll('style'));
    for( const style of styles ) head.removeChild( style );
  }
  afterAll(cleanStylesFromDom);
});
