import { AppState } from 'shared/models/state.model';
import { <%= camelize(name) %><%= formSuffix %>Reducer, <%= camelize(name) %><%= formSuffix %>State } from '../<%= maybeAppendForm(dasherize(name)) %>.reducer';

// necessary to avoid the error :
// Invalid module name in augmentation, module 'shared/models/state.model' cannot be found.
let happy_compiler: AppState; // tslint:disable-line

describe('<%= classify(name) %><%= formSuffix %> Reducer', () => {

  describe('undefined action', () => {

    it('should return the default state', () => {
      const action = { type: null, payload: null };
      const state = <%= camelize(name) %><%= formSuffix %>Reducer( undefined, action );

      expect(state).toBe(<%= camelize(name) %><%= formSuffix %>State);
    });

  });

} );
