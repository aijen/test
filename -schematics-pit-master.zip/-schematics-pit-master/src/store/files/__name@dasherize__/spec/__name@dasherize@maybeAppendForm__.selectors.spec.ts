
describe('<%= classify(name) %><%= formSuffix %> Selectors', () => {

} );
