import { TestBed } from '@angular/core/testing';
import { RouterTestingModule } from '@angular/router/testing';
import { provideMockActions } from '@ngrx/effects/testing';
import { provideMockStore } from '@ngrx/store/testing';
import { configureTestSuite } from 'ng-bullet';
import { Observable } from 'rxjs';
import { AppState } from 'shared/models/state.model';
import { MessageHandler } from 'shared/services/messageHandler.service';
import { <%= classify(name) %><%= formSuffix %>Effects } from '../<%= maybeAppendForm(dasherize(name)) %>.effects';
import { <%= camelize(name) %><%= formSuffix %>State } from '../<%= maybeAppendForm(dasherize(name)) %>.reducer';
import { <%= classify(name) %><%= formSuffix %>Service } from '../<%= maybeAppendForm(dasherize(name)) %>.service';

describe('<%= classify(name) %><%= formSuffix %> Effects', () => {
  let service: <%= classify(name) %><%= formSuffix %>Effects;
  let actions: Observable<any>;
  let <%= camelize(name) %><%= formSuffix %>ServiceStub: jasmine.SpyObj<<%= classify(name) %><%= formSuffix %>Service>;
  let messageHandlerStub: jasmine.SpyObj<MessageHandler>;

  configureTestSuite(() => {
    TestBed.configureTestingModule({
      imports: [
        RouterTestingModule
      ],
      providers: [
        <%= classify(name) %><%= formSuffix %>Effects,
        provideMockActions(() => actions),
        provideMockStore<Partial<AppState>>({ initialState: { <%= camelize(name) %><%= formSuffix %>: <%= camelize(name) %><%= formSuffix %>State } }),
        { provide: <%= classify(name) %><%= formSuffix %>Service, useFactory: () => jasmine.createSpyObj('<%= classify(name) %><%= formSuffix %>Service', ['load', 'save'] as Array<keyof <%= classify(name) %><%= formSuffix %>Service>) },
        { provide: MessageHandler, useFactory: () => jasmine.createSpyObj('MessageHandler', ['ngOnDestroy', 'show'] as Array<keyof MessageHandler>) },
      ]
    });
  } );

  beforeEach(() => {
    actions = null;
    <%= camelize(name) %><%= formSuffix %>ServiceStub = TestBed.get(<%= classify(name) %><%= formSuffix %>Service);
    messageHandlerStub = TestBed.get(MessageHandler);
    service = TestBed.get(<%= classify(name) %><%= formSuffix %>Effects);
  });

  it('should work', () => {
    expect(service).toBeTruthy();
  });


  /** prevent memory leaks by removing leftover styles in <head> */
  function cleanStylesFromDom(): void {
    const head = document.head;
    const styles = Array.from(head.querySelectorAll('style'));
    for( const style of styles ) head.removeChild( style );
  }
  afterAll(cleanStylesFromDom);
} );
