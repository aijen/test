import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { LOAD_<%= upperize(name) %>_URL, SAVE_<%= upperize(name) %>_URL } from 'core/services/http/http-client.service';
import { map } from 'rxjs/operators';
import { <%= classify(name) %><%= formSuffix %>Value, <%= classify(name) %><%= formSuffix %>DTO } from './<%= maybeAppendForm(dasherize(name)) %>.model';
<% if(isForm) { %>
const toJson = ( <%= camelize(name) %><%= formSuffix %>: <%= classify(name) %><%= formSuffix %>Value ): <%= classify(name) %><%= formSuffix %>DTO => {
  return {
    ...<%= camelize(name) %><%= formSuffix %>,
  };
}
<% } %>
const fromJson = ( dto: <%= classify(name) %><%= formSuffix %>DTO ): <%= classify(name) %><%= formSuffix %>Value => {
  return {
    ...dto,
  };
}

@Injectable({
  providedIn: 'root'
})
export class <%= classify(name) %><%= formSuffix %>Service {

  constructor(
    private http: HttpClient,
  ) {}

  load() {
    return this.http.get<<%= classify(name) %><%= formSuffix %>DTO>(LOAD_<%= upperize(name) %>_URL).pipe( map( fromJson ) );
  }
<% if(isForm) { %>
  save( <%= camelize(name) %><%= formSuffix %>: <%= classify(name) %><%= formSuffix %>Value ) {
    return this.http.put(SAVE_<%= upperize(name) %>_URL, toJson( <%= camelize(name) %><%= formSuffix %> ), { responseType: 'text' });
  }
<% } %>
}
