import { Injectable } from '@angular/core';
import { Router } from '@angular/router';
import { Actions, Effect, ofType } from '@ngrx/effects';
import { Store } from '@ngrx/store';
import { concat, of } from 'rxjs';
import { catchError, map, switchMap, tap<% if(isForm) { %>, withLatestFrom<% } %> } from 'rxjs/operators';
import { AppState } from 'shared/models/state.model';
import { MessageHandler } from 'shared/services/messageHandler.service';
import { <%= classify(name) %><%= formSuffix %>ActionTypes, Load<%= classify(name) %><%= formSuffix %>, Load<%= classify(name) %><%= formSuffix %>Error, Load<%= classify(name) %><%= formSuffix %>Success<% if(isForm) { %>, Save<%= classify(name) %><%= formSuffix %>, Save<%= classify(name) %><%= formSuffix %>Error, Save<%= classify(name) %><%= formSuffix %>Success<% } %> } from './<%= maybeAppendForm(dasherize(name)) %>.actions';<% if(isForm) { %>
import { get<%= classify(name) %><%= formSuffix %> } from './<%= maybeAppendForm(dasherize(name)) %>.selectors';<% } %>
import { <%= classify(name) %><%= formSuffix %>Service } from './<%= maybeAppendForm(dasherize(name)) %>.service';

@Injectable()
export class <%= classify(name) %><%= formSuffix %>Effects {

  public static messages = {
    loadError: `
      Une erreur est survenue pendant le chargement de la configuration '<%= classify(name) %>': Veuillez réessayer
    `,<% if(isForm) { %>
    saveSuccess: `
      Configuration sauvegardée
    `,
    saveError: `
      Une erreur est survenue pendant la sauvegarde, veuillez réessayer ou contacter le support si le problème persiste
    `,<% } %>
  }
<% if(isForm) { %>
  <%= camelize(name) %><%= formSuffix %>$ = this.store$.select( get<%= classify(name) %><%= formSuffix %> ).pipe(
    map( <%= camelize(name) %><%= formSuffix %> => <%= camelize(name) %><%= formSuffix %>.value ),
  );
<% } %>
  constructor(
    private store$: Store<AppState>,
    private actions$: Actions,
    private <%= dasherize(name) %><%= formSuffix %>Service: <%= classify(name) %><%= formSuffix %>Service,
    private router: Router,
    private snackbar: MessageHandler,
  ) {}

  @Effect()
  load$ = this.actions$.pipe(
    ofType<Load<%= classify(name) %><%= formSuffix %>>( <%= classify(name) %><%= formSuffix %>ActionTypes.Load<%= classify(name) %><%= formSuffix %> ),
    switchMap( () => this.<%= dasherize(name) %><%= formSuffix %>Service.load() ),
    map( <%= camelize(name) %><%= formSuffix %> => new Load<%= classify(name) %><%= formSuffix %>Success( { <%= camelize(name) %><%= formSuffix %> } ) ),
    catchError( (error, caught) => concat(of(new Load<%= classify(name) %><%= formSuffix %>Error( { error } )), caught) ),
  );

  @Effect({ dispatch: false })
  loadError$ = this.actions$.pipe(
    ofType<Load<%= classify(name) %><%= formSuffix %>Error>( <%= classify(name) %><%= formSuffix %>ActionTypes.Load<%= classify(name) %><%= formSuffix %>Error ),
    tap( action => { console.error(action.payload.error); this.snackbar.show( { message: <%= classify(name) %><%= formSuffix %>Effects.messages.loadError, action: 'OK', isError: true } )} ),
  );
<% if(isForm) { %>
  @Effect()
  save$ = this.actions$.pipe(
    ofType<Save<%= classify(name) %><%= formSuffix %>>( <%= classify(name) %><%= formSuffix %>ActionTypes.Save<%= classify(name) %><%= formSuffix %> ),
    withLatestFrom( this.<%= camelize(name) %><%= formSuffix %>$ ),
    switchMap( ([action, _form]) => of(_form).pipe(
      switchMap( form => this.<%= dasherize(name) %><%= formSuffix %>Service.save( form ) ),
      map( () => new Save<%= classify(name) %><%= formSuffix %>Success() ),
      tap( () => action.payload.andQuit ? this.router.navigate(['/']) : null ),
      catchError( error => of(new Save<%= classify(name) %><%= formSuffix %>Error( { error } )) ),
    ) ),
  );

  @Effect()
  saveSuccess$ = this.actions$.pipe(
    ofType<Save<%= classify(name) %><%= formSuffix %>Success>( <%= classify(name) %><%= formSuffix %>ActionTypes.Save<%= classify(name) %><%= formSuffix %>Success ),
    tap( () => this.snackbar.show( { message: <%= classify(name) %><%= formSuffix %>Effects.messages.saveSuccess } ) ),
    map( () => new Load<%= classify(name) %><%= formSuffix %>() ),
  );

  @Effect( { dispatch: false } )
  saveError$ = this.actions$.pipe(
    ofType<Save<%= classify(name) %><%= formSuffix %>Error>( <%= classify(name) %><%= formSuffix %>ActionTypes.Save<%= classify(name) %><%= formSuffix %>Error ),
    tap( action => { console.error(action.payload.error); this.snackbar.show( { message: <%= classify(name) %><%= formSuffix %>Effects.messages.saveError, action: 'OK', isError: true } )} ),
  );
<% } %>
}
