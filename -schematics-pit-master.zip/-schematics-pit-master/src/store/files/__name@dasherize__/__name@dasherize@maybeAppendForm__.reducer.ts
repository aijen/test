<% if(isForm) { %>import { enableIfStable } from 'core/utils/forms.helpers';
import { createFormGroupState, createFormStateReducerWithUpdate, disable, FormGroupState, reset, setValue, updateGroup } from 'ngrx-forms';
<% } %>import { <%= classify(name) %><%= formSuffix %>ActionTypes, <%= classify(name) %><%= formSuffix %>ActionUnion } from './<%= maybeAppendForm(dasherize(name)) %>.actions';
import { <%= classify(name) %><%= formSuffix %>State<% if(isForm) { %>, <%= classify(name) %><%= formSuffix %>Value<% } %> } from './<%= maybeAppendForm(dasherize(name)) %>.model';
<% if(isForm) { %>
const FORM_ID = 'ADMIN_<%= upperize(name) %>_FORM';

const initial<%= formSuffix %>State = createFormGroupState<<%= classify(name) %><%= formSuffix %>Value>(FORM_ID, {
});

const formUpdate = updateGroup<<%= classify(name) %><%= formSuffix %>Value>( {
} );

const formValidation = updateGroup<<%= classify(name) %><%= formSuffix %>Value>( {
} );

const updateAndValidate = ( <%= camelize(name) %><%= formSuffix %>: FormGroupState<<%= classify(name) %><%= formSuffix %>Value> ) => formValidation(formUpdate(<%= camelize(name) %><%= formSuffix %>));

const formReducer = createFormStateReducerWithUpdate(updateAndValidate);
<% } %>
export const <%= camelize(name) %><%= formSuffix %>State: <%= classify(name) %><%= formSuffix %>State = {<% if(isForm) { %>
  <%= camelize(name) %><%= formSuffix %>: updateAndValidate(initial<%= formSuffix %>State),
  default<%= classify(name) %><%= formSuffix %>: null,
  isSaving: false,<% } else { %>
  <%= camelize(name) %><%= formSuffix %>: {},<% } %>
  isLoading: false,
};

export function <%= camelize(name) %><%= formSuffix %>Reducer(
  state = <%= camelize(name) %><%= formSuffix %>State,
  action: <%= classify(name) %><%= formSuffix %>ActionUnion
): <%= classify(name) %><%= formSuffix %>State {
<% if(isForm) { %>
  const <%= camelize(name) %><%= formSuffix %> = formReducer(state.<%= camelize(name) %><%= formSuffix %>, action);

  if(<%= camelize(name) %><%= formSuffix %> !== state.<%= camelize(name) %><%= formSuffix %>) {
    state = { ...state, <%= camelize(name) %><%= formSuffix %> };
  }
<% } %>
  switch( action.type ) {

    case <%= classify(name) %><%= formSuffix %>ActionTypes.Load<%= classify(name) %><%= formSuffix %>: {
      return {
        ...state,<% if(isForm) { %>
        <%= camelize(name) %><%= formSuffix %>: disable(state.<%= camelize(name) %><%= formSuffix %>),<% } %>
        isLoading: true,
      };
    }
    case <%= classify(name) %><%= formSuffix %>ActionTypes.Load<%= classify(name) %><%= formSuffix %>Error: {
      return {
        ...state,
        isLoading: false,
      };
    }
    // Optimistic save, assumes no change were done on the server between saves
    case <%= classify(name) %><%= formSuffix %>ActionTypes.Load<%= classify(name) %><%= formSuffix %>Success: {
      const { <%= camelize(name) %><%= formSuffix %> } = action.payload;<% if(isForm) { %>
      const { isSaving } = state;<% } %>

      return {
        ...state,<% if(isForm) { %>
        <%= camelize(name) %><%= formSuffix %>: updateAndValidate(enableIfStable(reset(setValue(state.<%= camelize(name) %><%= formSuffix %>, <%= camelize(name) %><%= formSuffix %>)), { isSaving, isLoading: false } )),
        default<%= classify(name) %><%= formSuffix %>: <%= camelize(name) %><%= formSuffix %>,<% } else { %>
        <%= camelize(name) %><%= formSuffix %>,<% } %>
        isLoading: false,
      };
    }
<% if(isForm) { %>
    case <%= classify(name) %><%= formSuffix %>ActionTypes.Reset<%= classify(name) %><%= formSuffix %>: {
      const { default<%= classify(name) %><%= formSuffix %> } = state;
      return {
        ...state,
        <%= camelize(name) %><%= formSuffix %>: updateAndValidate(reset(setValue(state.<%= camelize(name) %><%= formSuffix %>, default<%= classify(name) %><%= formSuffix %> ))),
      }
    }

    case <%= classify(name) %><%= formSuffix %>ActionTypes.Save<%= classify(name) %><%= formSuffix %>: {
      return {
        ...state,
        <%= camelize(name) %><%= formSuffix %>: disable(state.<%= camelize(name) %><%= formSuffix %>),
        isSaving: true,
      };
    }
    case <%= classify(name) %><%= formSuffix %>ActionTypes.Save<%= classify(name) %><%= formSuffix %>Success: {
      const { isLoading } = state;

      return {
        ...state,
        <%= camelize(name) %><%= formSuffix %>: updateAndValidate(enableIfStable(reset(state.<%= camelize(name) %><%= formSuffix %>), { isSaving: false, isLoading } )),
        default<%= classify(name) %><%= formSuffix %>: state.<%= camelize(name) %><%= formSuffix %>.value,
        isSaving: false,
      };
    }
    case <%= classify(name) %><%= formSuffix %>ActionTypes.Save<%= classify(name) %><%= formSuffix %>Error: {
      const { isLoading } = state;

      return {
        ...state,
        <%= camelize(name) %><%= formSuffix %>: updateAndValidate(enableIfStable(state.<%= camelize(name) %><%= formSuffix %>, { isSaving: false, isLoading } )),
        isSaving: false,
      };
    }
<% } %>
    default: {
      return state;
    }
  }
}
