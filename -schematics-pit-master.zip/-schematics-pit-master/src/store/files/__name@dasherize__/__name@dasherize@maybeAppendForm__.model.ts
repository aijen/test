import { FormGroupState } from 'ngrx-forms';

declare module 'shared/models/state.model' {
  export interface AppState {
    readonly <%= camelize(name) %><%= formSuffix %>: <%= classify(name) %><%= formSuffix %>State;
  }
}
export interface <%= classify(name) %><%= formSuffix %>Value {
}

export interface <%= classify(name) %><%= formSuffix %>DTO {
}

export interface <%= classify(name) %><%= formSuffix %>State {<% if(isForm) { %>
  <%= camelize(name) %><%= formSuffix %>: FormGroupState<<%= classify(name) %><%= formSuffix %>Value>;
  default<%= classify(name) %><%= formSuffix %>: <%= classify(name) %><%= formSuffix %>Value;
  isSaving: boolean;<% } else { %>
  <%= camelize(name) %><%= formSuffix %>: <%= classify(name) %><%= formSuffix %>Value;<% } %>
  isLoading: boolean;
}
