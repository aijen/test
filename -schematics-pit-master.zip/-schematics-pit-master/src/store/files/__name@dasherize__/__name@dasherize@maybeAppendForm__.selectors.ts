import { createFeatureSelector, createSelector } from '@ngrx/store';
import { <%= classify(name) %><%= formSuffix %>State } from './<%= maybeAppendForm(dasherize(name)) %>.model';

export const <%= camelize(name) %><%= formSuffix %>StateSelector = createFeatureSelector<<%= classify(name) %><%= formSuffix %>State>(
  '<%= camelize(name) %><%= formSuffix %>'
);

export const get<%= classify(name) %><%= formSuffix %> = createSelector(
  <%= camelize(name) %><%= formSuffix %>StateSelector,
  state => state.<%= camelize(name) %><%= formSuffix %>,
);

export const is<%= classify(name) %><%= formSuffix %>Loading = createSelector(
  <%= camelize(name) %><%= formSuffix %>StateSelector,
  state => state.isLoading,
);<% if(isForm) { %>

export const is<%= classify(name) %><%= formSuffix %>LoadingOrSaving = createSelector(
  <%= camelize(name) %><%= formSuffix %>StateSelector,
  state => state.isLoading || state.isSaving,
);

export const isModified = createSelector(
  get<%= classify(name) %><%= formSuffix %>,
  is<%= classify(name) %><%= formSuffix %>Loading,
  ( <%= camelize(name) %><%= formSuffix %>, loading ) => !(<%= camelize(name) %><%= formSuffix %>.isPristine || loading),
);<% } %>
