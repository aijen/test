import { NgModule } from '@angular/core';
import { EffectsModule } from '@ngrx/effects';
import { StoreModule } from '@ngrx/store';
import { <%= classify(name) %><%= formSuffix %>Effects } from './<%= maybeAppendForm(dasherize(name)) %>.effects';
import { <%= camelize(name) %><%= formSuffix %>Reducer } from './<%= maybeAppendForm(dasherize(name)) %>.reducer';

@NgModule({
  declarations: [],
  imports: [
    StoreModule.forFeature('<%= camelize(name) %><%= formSuffix %>', <%= camelize(name) %><%= formSuffix %>Reducer),
    EffectsModule.forFeature([<%= classify(name) %><%= formSuffix %>Effects]),
  ]
})
export class <%= classify(name) %><%= formSuffix %>StoreModule { }
