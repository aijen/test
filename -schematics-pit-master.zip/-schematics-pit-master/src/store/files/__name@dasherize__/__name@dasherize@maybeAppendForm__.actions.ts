import { Action } from '@ngrx/store';
import { <%= classify(name) %><%= formSuffix %>Value } from './<%= maybeAppendForm(dasherize(name)) %>.model';

export enum <%= classify(name) %><%= formSuffix %>ActionTypes {
  Load<%= classify(name) %><%= formSuffix %> = '[<%= classify(name) %>] Load<%= formSuffix %>',
  Load<%= classify(name) %><%= formSuffix %>Success = '[<%= classify(name) %>] Load<%= formSuffix %>Success',
  Load<%= classify(name) %><%= formSuffix %>Error = '[<%= classify(name) %>] Load<%= formSuffix %>Error',<% if(isForm) { %>
  Reset<%= classify(name) %><%= formSuffix %> = '[<%= classify(name) %>] Reset<%= formSuffix %>',
  Save<%= classify(name) %><%= formSuffix %> = '[<%= classify(name) %>] Save<%= formSuffix %>',
  Save<%= classify(name) %><%= formSuffix %>Success = '[<%= classify(name) %>] Save<%= formSuffix %>Success',
  Save<%= classify(name) %><%= formSuffix %>Error = '[<%= classify(name) %>] Save<%= formSuffix %>Error',<% } %>
}

export class Load<%= classify(name) %><%= formSuffix %> implements Action {
  readonly type = <%= classify(name) %><%= formSuffix %>ActionTypes.Load<%= classify(name) %><%= formSuffix %>;
  constructor() {}
}

export class Load<%= classify(name) %><%= formSuffix %>Success implements Action {
  readonly type = <%= classify(name) %><%= formSuffix %>ActionTypes.Load<%= classify(name) %><%= formSuffix %>Success;
  constructor( public payload: { <%= camelize(name) %><%= formSuffix %>: <%= classify(name) %><%= formSuffix %>Value } ) {}
}

export class Load<%= classify(name) %><%= formSuffix %>Error implements Action {
  readonly type = <%= classify(name) %><%= formSuffix %>ActionTypes.Load<%= classify(name) %><%= formSuffix %>Error;
  constructor( public payload: { error: Error } ) {}
}
<% if(isForm) { %>
export class Reset<%= classify(name) %><%= formSuffix %> implements Action {
  readonly type = <%= classify(name) %><%= formSuffix %>ActionTypes.Reset<%= classify(name) %><%= formSuffix %>;
  constructor() {}
}

export class Save<%= classify(name) %><%= formSuffix %> implements Action {
  readonly type = <%= classify(name) %><%= formSuffix %>ActionTypes.Save<%= classify(name) %><%= formSuffix %>;
  constructor( public payload: { andQuit?: boolean } = {} ) {}
}

export class Save<%= classify(name) %><%= formSuffix %>Success implements Action {
  readonly type = <%= classify(name) %><%= formSuffix %>ActionTypes.Save<%= classify(name) %><%= formSuffix %>Success;
  constructor() {}
}

export class Save<%= classify(name) %><%= formSuffix %>Error implements Action {
  readonly type = <%= classify(name) %><%= formSuffix %>ActionTypes.Save<%= classify(name) %><%= formSuffix %>Error;
  constructor( public payload: { error: Error } ) {}
}
<% } %>
export type <%= classify(name) %><%= formSuffix %>ActionUnion =
  | Load<%= classify(name) %><%= formSuffix %>
  | Load<%= classify(name) %><%= formSuffix %>Success
  | Load<%= classify(name) %><%= formSuffix %>Error<% if(isForm) { %>
  | Reset<%= classify(name) %><%= formSuffix %>
  | Save<%= classify(name) %><%= formSuffix %>
  | Save<%= classify(name) %><%= formSuffix %>Success
  | Save<%= classify(name) %><%= formSuffix %>Error<% } %>
  ;
