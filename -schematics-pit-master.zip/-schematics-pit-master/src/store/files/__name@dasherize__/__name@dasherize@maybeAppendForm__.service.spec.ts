import { HttpClientTestingModule, HttpTestingController } from '@angular/common/http/testing';
import { TestBed } from '@angular/core/testing';
import { configureTestSuite } from 'ng-bullet';
import { <%= classify(name) %><%= formSuffix %>Service } from './<%= maybeAppendForm(dasherize(name)) %>.service';

describe('<%= classify(name) %><%= formSuffix %>Service', () => {
  let httpTestingController: HttpTestingController;
  let service: <%= classify(name) %><%= formSuffix %>Service;

  configureTestSuite(() => {
    TestBed.configureTestingModule({
      imports: [ HttpClientTestingModule ],
      providers: [ <%= classify(name) %><%= formSuffix %>Service ],
    })
  });

  beforeEach(() => {
    httpTestingController = TestBed.get(HttpTestingController);
    service = TestBed.get(<%= classify(name) %><%= formSuffix %>Service);
  });

  afterEach(() => {
    httpTestingController.verify();
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });


  /** prevent memory leaks by removing leftover styles in <head> */
  function cleanStylesFromDom(): void {
    const head = document.head;
    const styles = Array.from(head.querySelectorAll('style'));
    for( const style of styles ) head.removeChild( style );
  }
  afterAll(cleanStylesFromDom);
});
