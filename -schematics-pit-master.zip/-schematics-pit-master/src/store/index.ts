import { strings } from '@angular-devkit/core';
import { apply, mergeWith, move, Rule, SchematicContext, SchematicsException, template, Tree, url } from '@angular-devkit/schematics';
import { parseName } from '@schematics/angular/utility/parse-name';
import { buildDefaultPath } from '@schematics/angular/utility/project';
import { Schema } from './schema';

// You don't have to export the function as default. You can also have more than one rule factory
// per file.
export default function(_options: Schema): Rule {
  return (tree: Tree, _context: SchematicContext) => {
    const workspaceConfigBuffer = tree.read('angular.json');
    if(!workspaceConfigBuffer) {
      throw new SchematicsException('Not an Angular CLI workspace');
    }

    const workspaceConfig = JSON.parse(workspaceConfigBuffer.toString());
    const projectName = _options.project || workspaceConfig.defaultProject;
    const project = workspaceConfig.projects[projectName];

    const defaultProjectPath = buildDefaultPath(project);

    const parsedPath = parseName(defaultProjectPath, _options.name);

    const { name, path } = parsedPath;

    const sourceTemplate = url('./files');

    const sourceParametrizedTemplate = apply(sourceTemplate, [
      template({
        ..._options,
        ...strings,
        name,
        formSuffix: _options.form ? 'Form' : '',
        isForm: _options.form,
        maybeAppendForm: ( s: string ) => _options.form ? `${s}.form` : s,
        upperize,
      }),
      move(path)
    ]);

    function upperize( s: string ) {
      return strings.underscore(s).toUpperCase();
    }

    return mergeWith(sourceParametrizedTemplate)(tree, _context);
  };
}
