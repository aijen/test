/**
 * Pit Options Schema
 * Pit Schematics
 */
export interface Schema {
    /**
     * store name
     */
    name: string;
    /**
     * is ngrx form
     */
    form: string;
    /**
     * Angular CLI workspace project
     */
    project?: string;
}
