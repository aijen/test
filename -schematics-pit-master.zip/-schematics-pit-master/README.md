# Getting Started With Schematics

This repository is a basic Schematic implementation that serves as a starting point to create and publish Schematics to NPM.

### Testing

To test locally, install `@angular-devkit/schematics-cli` globally and use the `schematics` command line tool. That tool acts the same as the `generate` command of the Angular CLI, but also has a debug mode.

Check the documentation with
```bash
schematics --help
```

### Unit Testing

`npm run test` will run the unit tests, using Jasmine as a runner and test framework.

### Publishing

To publish, simply do:

```bash
npm run build
npm publish
```

That's it!


### Installing

replace VERSION with the released version you want to install.

```bash
npm config set strict-ssl false
npm i --no-save https://sgithub.fr.world.socgen/X186590/-schematics-pit/releases/download/v2.0.3/schematics-pit-2.0.3.tgz
npm config set strict-ssl true
```

### How to use

```
ng g @schematics/pit:store storeName [--form]
ng g @schematics/pit:spec specName [--type=component|service|directive|store] [--flat]
ng g @schematics/pit:autospec file [--classname="classConstructorName"] [--subdir="relativePath"]
```
